function [Ganhos,Yest,MSE,BASES] = PSO (func_number,AMOSTRAS,t,Ts)

    %DEFINI��ES INICIAIS
	w = 0.1;
	c1 = 1;
	c2 = 1;
    dim_pop = length(AMOSTRAS);
    swarm = struct('ganhos',{},'fitness',{},'bases',{});
    swarm_melhores = struct('ganhos',{},'fitness',{},'bases',{});
    nInt = 30;
    
    %swarm_melhores = inf;
	velocidade = zeros(dim_pop,func_number);
	%todos_melhores = zeros (nInt,1);
    vPos = 1;
    melhor = inf;

    %GERA GANHOS ALEAT�RIOS 
    for i = 1:dim_pop
        swarm(i).ganhos = rand(1,func_number);
        swarm(i).fitness = inf;
    end
    
	swarm_melhores = swarm;
	
	for i = 1:nInt
		[melhor,vPos,swarm_fit,swarm_melhores] = Fit (swarm,swarm_melhores,melhor,vPos,dim_pop,func_number,AMOSTRAS,t,Ts);
		velocidade = calc_velocidade (swarm_fit,swarm_melhores,velocidade,vPos,dim_pop,w,c1,c2);
		swarm = posicao (swarm_fit,velocidade,dim_pop);
		
	end%for
    
    %VARIAVEIS QUE SER�O RETORNADAS
    Yk = [];
    Ganhos = melhor.ganhos;
    MSE = melhor.fitness;
    BASES = melhor.bases;
    
    %RECALCULA O RESULTADO GERADO PARA RETORNAR AO USU�RIO
    for j = 1:func_number        
         Yk = [Yk lsim(melhor(1).bases{j},AMOSTRAS,t)];   %verificar se � 'u' ou 'AMOSTRAS'!!        
    end
    
    Yest = Ganhos * Yk';
end %function




