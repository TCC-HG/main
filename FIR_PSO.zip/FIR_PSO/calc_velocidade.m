function velocidade = calc_velocidade (swarm,swarm_melhores,velocidade,vPos,dim_pop,w,c1,c2)

	for i = 1:dim_pop
		velocidade(i,:) = w*velocidade(i,:) + c1*rand*(swarm_melhores(i).ganhos-swarm(i).ganhos) + c2*rand*(swarm_melhores(vPos).ganhos-swarm(i).ganhos);				
	end% for
end% function
