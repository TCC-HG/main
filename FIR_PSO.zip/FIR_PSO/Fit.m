function [melhor_fit,vPos,swarm_fit,swarm_melhores] = Fit (swarm,swarm_melhores,melhor,vPos,dim_pop,func_number,AMOSTRAS,temp,Ts)
	
    swarm_fit = struct('ganhos',{},'fitness',{},'bases',{});
    melhor_fit = struct('ganhos',{},'fitness',{},'bases',{});
    minimo = inf;
    Yk = [];
    num_base = [1];
    den_base = [1 0];    
    delg = tf(num_base,den_base,Ts);
    BASES{1} = delg;
    
    % GERA BASES 
    for n = 1:func_number
        if n >= 2
                BASES{n} = BASES{n-1}*delg; %n-�sima fun��o
        end
        %FILTRAGEM DAS AMOSTRAS COM AS BASES DO FILTRO
        Yk = [Yk lsim(BASES{n},AMOSTRAS,temp)];
    end
    
    for i = 1:dim_pop %#ok<ALIGN>
        
         Yest = (swarm(i).ganhos * Yk');
         swarm_fit(i).ganhos = swarm(i).ganhos;
         
         %AJUSTES NECESS�RIOS PARA RETIRADA DOS ATRASOS DE FILTRAGEM
         a = (AMOSTRAS(1:end-func_number,:));
         b = Yest(:,func_number:end-1)';
         swarm_fit(i).fitness = sum((a-b).^2)/length(AMOSTRAS);
         swarm_fit(i).bases = BASES;
         
		if (swarm_melhores(i).fitness > swarm_fit(i).fitness)
			swarm_melhores(i) = swarm_fit(i);
									
			if (swarm_melhores(i).fitness < abs(minimo))
				melhor_fit = swarm_melhores(i);
                minimo = swarm_melhores(i).fitness;
				vPos = i;
			end %if			
		end%if
	end %for
end %function