function swarm = posicao (swarm_fit,velocidade,dim_pop)

    swarm = struct('ganhos',{},'fitness',{},'bases',{});
	for i = 1:dim_pop
		swarm(i).ganhos = swarm_fit(i).ganhos + velocidade(i,:);
	end% for	
end %posicao
