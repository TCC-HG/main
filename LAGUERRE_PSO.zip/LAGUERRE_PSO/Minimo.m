function [swarm_melhores] = Minimo (memoria,dim_pop)

    swarm_melhores = struct('ganhos',{},'fitness',{},'polos',{},'bases',{});
    minimo = inf;

    for i = 1:dim_pop
        if abs(memoria(i).fitness) < abs(minimo)
            minimo = memoria(i).fitness;
            swarm_melhores = memoria(i);
        end
    end
end