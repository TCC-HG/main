function [melhor_fit,vPos,swarm_fit,swarm_melhores] = Fit (swarm,swarm_melhores,melhor,vPos,dim_pop,func_number,AMOSTRAS,temp,Ts)
	
    swarm_fit = struct('ganhos',{},'fitness',{},'polos',{},'bases',{});
    melhor_fit = struct('ganhos',{},'fitness',{},'polos',{},'bases',{});
    memoria = struct('ganhos',{},'fitness',{},'polos',{},'bases',{});
    minimo = inf;    
    
    for i = 1:dim_pop
        p = swarm(i).polos;
        Yk = [];
        
        %GERA��O DAS FUNC{N}, FUN��ES DE LAGUERRE
        BASES{1} = tf(sqrt(1-p^2),[1 -p],Ts); %Ts = -1 pois a amostragem nao importa
        delg = tf([-p 1],[1 -p],-1);

        for n = 1:func_number
            if n >= 2
                BASES{n} = BASES{n-1}*delg; %n-�sima fun��o
            end
            %FILTRAGEM DAS AMOSTRAS COM AS BASES DO FILTRO
            Yk = [Yk lsim(BASES{n},AMOSTRAS,temp)];       
        end
             
        for k = 1:dim_pop
            
             Yest = (swarm(k).ganhos * Yk');
             memoria(k).ganhos = swarm(k).ganhos;

             %AJUSTES NECESS�RIOS PARA RETIRADA DOS ATRASOS DE FILTRAGEM
             a = (AMOSTRAS(1:end-func_number,:));
             b = Yest(:,func_number:end-1)';
             memoria(k).fitness = sum((a-b).^2)/length(AMOSTRAS);
             memoria(k).polos = p;
             memoria(k).bases = BASES;
             
        end
        
               
        %COLOCA APENAS O MELHOR RESULTADO DO MSE PARA CADA POLO
        swarm_fit(i) = Minimo(memoria,dim_pop);
                
        if (swarm_melhores(i).fitness > swarm_fit(i).fitness)
                swarm_melhores(i) = swarm_fit(i);

                if (swarm_melhores(i).fitness < abs(minimo))
                    melhor_fit = swarm_melhores(i);
                    minimo = swarm_melhores(i).fitness;
                    vPos = i;
                end %if			
        end%if

        
    end
end %function