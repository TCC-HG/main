function swarm = posicao (swarm_fit,velocidade,dim_pop)

    swarm = struct('ganhos',{},'fitness',{},'polos',{},'bases',{});
	for i = 1:dim_pop
		swarm(i).ganhos = swarm_fit(i).ganhos + velocidade(i,:);
        swarm(i).fitness = swarm_fit(i).fitness;
        swarm(i).polos = swarm_fit(i).polos;
        swarm(i).bases = swarm_fit(i).bases;
	end% for	
end %posicao
