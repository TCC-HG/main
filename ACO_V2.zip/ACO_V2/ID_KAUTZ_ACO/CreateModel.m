function model = CreateModel(AMOSTRAS)
   
    D = rand(length(AMOSTRAS)+2,length(AMOSTRAS)+2);
     
    model.n = length(D); 
    model.D = D;
end