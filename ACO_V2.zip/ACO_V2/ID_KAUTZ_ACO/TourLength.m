function [L,MINIMO,BASES_BEST,POLOS] = TourLength(tour,model,AMOSTRAS,func_number,temp,Ts)

    n = length(func_number); %VERIFICAR SE � MELHOR CONTINUAR COM "func_number" OU USAR O "tour"
    L = [];
    MINIMO = inf;
    GANHOS = ones(1,func_number);
    
    for j = 1:func_number
        if func_number == 1
            tour = tour;
        else
            tour = [tour tour(j)];
        end
    end 
    
    for i = 1:n
        if (sqrt(model.D(tour(1,i),end-1)^2 + model.D(tour(1,i),end)^2) < 1)
            b = model.D(tour(1,i),end-1);
            c = model.D(tour(1,i),end);
            Yk = [];

            %GERA��O DAS FUNC{N}, FUN��ES DE KAUTZ
            num = [-c b*(c-1) 1];
            den = [1 +b*(c-1) -c];

            BASES{1} = tf(sqrt(1-c^2)*[1 -b 0],den,Ts); % FUN��O �MPAR
            BASES{2} = tf(sqrt((1-b^2)*(1-c^2)),den,Ts); % FUN��O PAR

            delg = tf(num,den,Ts);

            for j = 1:((func_number)/2+1)
                if j >= 2
                    BASES{2*j-1} = BASES{2*(j-1)-1}*delg; %N-�SIMA FUN��O �MPAR
                    BASES{2*j} = BASES{2*(j-1)}*delg; %N-�SIMA FUN��O PAR
                end  
            end

            for w = 1:func_number
                if w >= 2
                    BASES{w} = BASES{w-1}*delg; %n-�sima fun��o
                end
                %FILTRAGEM DAS AMOSTRAS COM AS BASES DO FILTRO
                Yk = [Yk lsim(BASES{w},AMOSTRAS,temp)];       
            end

            for k = 1:func_number
                GANHOS(1,k) = model.D(tour(i+(k-1)));
            end

            Yest = GANHOS*Yk';

            %AJUSTES NECESS�RIOS PARA RETIRADA DOS ATRASOS DE FILTRAGEM
            a = (AMOSTRAS(1:end-func_number,:));
            d = Yest(:,func_number:end-1)';
            ERRO = sum((a-d).^2)/length(AMOSTRAS);

            if ERRO < MINIMO    
                L = GANHOS;        
                MINIMO = ERRO; 
                BASES_BEST = BASES;
                POLOS = [b c];
            else
                POLOS = [b c];
            end
        else
            POLOS = [model.D(tour(1,i),end-1) model.D(tour(1,i),end)];
            BASES_BEST = 1;  %S� PARA RETORNAR ALGO
        end
    end
end