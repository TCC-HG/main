function [L,MINIMO] = TourLength(tour,model,AMOSTRAS,func_number,Yk)

    n = length(func_number); %VERIFICAR SE � MELHOR CONTINUAR COM "func_number" OU USAR O "tour"
    L = [];
    MINIMO = inf;
    GANHOS = ones(1,func_number);
    
    for j = 1:func_number
        if func_number == 1
            tour = tour;
        else
            tour = [tour tour(j)];
        end
    end       
   
    for i = 1:n
        for k = 1:func_number
            GANHOS(1,k) = model.D(tour(i+(k-1)));
        end
        
        Yest = GANHOS*Yk';
        w = GANHOS;
        %AJUSTES NECESS�RIOS PARA RETIRADA DOS ATRASOS DE FILTRAGEM
        a = (AMOSTRAS(1:end-func_number,:));
        b = Yest(:,func_number:end-1)';
        ERRO = sum((a-b).^2)/length(AMOSTRAS);
        
        if ERRO < MINIMO    
            L = GANHOS;        
            MINIMO = ERRO;           
        end
    end
end