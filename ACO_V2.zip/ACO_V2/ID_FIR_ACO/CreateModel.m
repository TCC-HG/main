function [model,Yk] = CreateModel(func_number,AMOSTRAS,temp,Ts)

    Yk = [];   
    num_base = [1];
    den_base = [1 0];    
    delg = tf(num_base,den_base,Ts);
    BASES{1} = delg;
    
    % GERA BASES 
    for n = 1:func_number
        if n >= 2
                BASES{n} = BASES{n-1}*delg; %n-�sima fun��o
        end
        %FILTRAGEM DAS AMOSTRAS COM AS BASES DO FILTRO
        Yk = [Yk lsim(BASES{n},AMOSTRAS,temp)];
    end
    
    D = rand(length(AMOSTRAS),length(AMOSTRAS));
     
    model.n = length(D); 
    model.D = D;
    model.B = BASES;

end