function [L,MINIMO,BASES_BEST,POLO] = TourLength(tour,model,AMOSTRAS,func_number,temp,Ts)

    n = length(func_number); %VERIFICAR SE � MELHOR CONTINUAR COM "func_number" OU USAR O "tour"
    L = [];
    MINIMO = inf;
    GANHOS = ones(1,func_number);
    
    for j = 1:func_number
        if func_number == 1
            tour = tour;
        else
            tour = [tour tour(j)];
        end
    end 
    
    for i = 1:n

        p = model.D(tour(1,i),end);
        Yk = [];

        %GERA��O DAS FUNC{N}, FUN��ES DE LAGUERRE
        BASES{1} = tf(sqrt(1-p^2),[1 -p],Ts); %Ts = -1 pois a amostragem nao importa
        delg = tf([-p 1],[1 -p],-1);

        for w = 1:func_number
            if w >= 2
                BASES{w} = BASES{w-1}*delg; %n-�sima fun��o
            end
            %FILTRAGEM DAS AMOSTRAS COM AS BASES DO FILTRO
            Yk = [Yk lsim(BASES{w},AMOSTRAS,temp)];       
        end

        for k = 1:func_number
            GANHOS(1,k) = model.D(tour(i+(k-1)));
        end

        Yest = GANHOS*Yk';

        %AJUSTES NECESS�RIOS PARA RETIRADA DOS ATRASOS DE FILTRAGEM
        a = (AMOSTRAS(1:end-func_number,:));
        b = Yest(:,func_number:end-1)';
        ERRO = sum((a-b).^2)/length(AMOSTRAS);

        if ERRO < MINIMO    
            L = GANHOS;        
            MINIMO = ERRO; 
            BASES_BEST = BASES;
            POLO = p;
        else
            POLO = p;
        end
    end
end