function model = CreateModel(AMOSTRAS)
   
    D = rand(length(AMOSTRAS)+1,length(AMOSTRAS)+1);
     
    model.n = length(D); 
    model.D = D;
end