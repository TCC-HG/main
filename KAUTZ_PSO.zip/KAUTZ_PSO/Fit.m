function [melhor_fit,vPos,swarm_fit,swarm_melhores] = Fit (swarm,swarm_melhores,melhor,vPos,dim_pop,func_number,AMOSTRAS,temp,Ts)
	
    swarm_fit = struct('ganhos',{},'fitness',{},'polos',{},'bases',{});
    melhor_fit = struct('ganhos',{},'fitness',{},'polos',{},'bases',{});
    memoria = struct('ganhos',{},'fitness',{},'polos',{},'bases',{});
    minimo = inf;    
    
    for i = 1:dim_pop
        if (sqrt(swarm(i).polos(1)^2 + swarm(i).polos(2)^2) < 1)
            b = swarm(i).polos(1);
            c = swarm(i).polos(2);
            Yk = [];

            %GERA��O DAS FUNC{N}, FUN��ES DE KAUTZ
            num = [-c b*(c-1) 1];
            den = [1 +b*(c-1) -c];

            BASES{1} = tf(sqrt(1-c^2)*[1 -b 0],den,Ts); % FUN��O �MPAR
            BASES{2} = tf(sqrt((1-b^2)*(1-c^2)),den,Ts); % FUN��O PAR

            delg = tf(num,den,Ts);

            for n = 1:((func_number)/2+1)
                if n >= 2
                    BASES{2*n-1} = BASES{2*(n-1)-1}*delg; %N-�SIMA FUN��O �MPAR
                    BASES{2*n} = BASES{2*(n-1)}*delg; %N-�SIMA FUN��O PAR
                end  
            end
            
            for j = 1:func_number
                %FILTRAGEM DAS AMOSTRAS COM AS BASES DO FILTRO
                Yk = [Yk lsim(BASES{j},AMOSTRAS,temp)]; %VERIFICAR ESTA CONSTRU��O
            end

            for k = 1:dim_pop

                 Yest = (swarm(k).ganhos * Yk');
                 memoria(k).ganhos = swarm(k).ganhos;

                 %AJUSTES NECESS�RIOS PARA RETIRADA DOS ATRASOS DE FILTRAGEM
                 a = (AMOSTRAS(1:end-func_number,:));
                 d = Yest(:,func_number:end-1)';
                 memoria(k).fitness = sum((a-d).^2)/length(AMOSTRAS);
                 memoria(k).polos = [b c]; 
                 memoria(k).bases = BASES;
            end
            %COLOCA APENAS O MELHOR RESULTADO DO MSE PARA CADA POLO
            swarm_fit(i) = Minimo(memoria,dim_pop);
       
        else
            swarm_fit(i).ganhos = swarm(i).ganhos;
            swarm_fit(i).bases = swarm(i).bases;
            swarm_fit(i).polos = swarm(i).polos;
            swarm_fit(i).fitness = 10; %VALOR ALTO PARA SER DESCARTADO, MAS QUE N�O ZOE O FITMED        
        end
        
        if (swarm_melhores(i).fitness > swarm_fit(i).fitness)
            swarm_melhores(i) = swarm_fit(i);

            if (swarm_melhores(i).fitness < abs(minimo))
                melhor_fit = swarm_melhores(i);
                minimo = swarm_melhores(i).fitness;
                vPos = i;
            end %if			
        end%if        
    end
end %function